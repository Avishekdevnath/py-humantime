from .core import HumanTimeConverter

seconds_to_human = HumanTimeConverter.seconds_to_human
human_to_seconds = HumanTimeConverter.human_to_seconds
